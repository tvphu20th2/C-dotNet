﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Bai_2._7
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btn1_Click(object sender, EventArgs e)
        {
            int tong;
            tong = int.Parse(txt1.Text) + int.Parse(txt2.Text);
            MessageBox.Show("" + tong);

        }

        private void btn2_Click(object sender, EventArgs e)
        {
            int hn;
            hn = int.Parse(txt1.Text) - int.Parse(txt2.Text);
            MessageBox.Show("" + hn);

        }

        private void btn3_Click(object sender, EventArgs e)
        {
            double thuongqua;
            thuongqua = double.Parse(txt1.Text) / double.Parse(txt2.Text);
            MessageBox.Show("" + thuongqua);


        }

        private void btn4_Click(object sender, EventArgs e)
        {
            int Tich;
            Tich = int.Parse(txt1.Text) * int.Parse(txt2.Text);
            MessageBox.Show("" + Tich);


        }
    }
}
