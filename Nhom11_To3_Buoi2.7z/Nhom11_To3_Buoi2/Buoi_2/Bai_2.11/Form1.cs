﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Bai_2._11
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btn1_Click(object sender, EventArgs e)
        {

            double chuvi;
            chuvi = (double.Parse(txt1.Text) + double.Parse(txt2.Text)) * 2;
            MessageBox.Show("" + chuvi);
        }

        private void btn4_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btn2_Click(object sender, EventArgs e)
        {
            double dt;
            dt = double.Parse(txt1.Text) * double.Parse(txt2.Text);
            MessageBox.Show("" + dt);
        }

        private void btn3_Click(object sender, EventArgs e)
        {
            double duongcheo;
            duongcheo = Math.Sqrt((double.Parse(txt1.Text) + double.Parse(txt2.Text)) * 2);
            MessageBox.Show("" + duongcheo);
        }
    }
}
