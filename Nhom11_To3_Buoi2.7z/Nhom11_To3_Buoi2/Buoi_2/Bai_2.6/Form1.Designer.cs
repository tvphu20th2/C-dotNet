﻿
namespace Bai_2._6
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.Ibl2 = new System.Windows.Forms.Label();
            this.Ibl3 = new System.Windows.Forms.Label();
            this.txt1 = new System.Windows.Forms.TextBox();
            this.txt2 = new System.Windows.Forms.TextBox();
            this.btn1 = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(279, 39);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(178, 34);
            this.label1.TabIndex = 0;
            this.label1.Text = "PHEP TOAN";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.btn1);
            this.groupBox1.Controls.Add(this.txt2);
            this.groupBox1.Controls.Add(this.txt1);
            this.groupBox1.Controls.Add(this.Ibl3);
            this.groupBox1.Controls.Add(this.Ibl2);
            this.groupBox1.Location = new System.Drawing.Point(190, 105);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(521, 257);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Thông tin";
            // 
            // Ibl2
            // 
            this.Ibl2.AutoSize = true;
            this.Ibl2.Location = new System.Drawing.Point(15, 43);
            this.Ibl2.Name = "Ibl2";
            this.Ibl2.Size = new System.Drawing.Size(20, 17);
            this.Ibl2.TabIndex = 2;
            this.Ibl2.Text = "a:";
            // 
            // Ibl3
            // 
            this.Ibl3.AutoSize = true;
            this.Ibl3.Location = new System.Drawing.Point(15, 92);
            this.Ibl3.Name = "Ibl3";
            this.Ibl3.Size = new System.Drawing.Size(20, 17);
            this.Ibl3.TabIndex = 3;
            this.Ibl3.Text = "b:";
            // 
            // txt1
            // 
            this.txt1.Location = new System.Drawing.Point(41, 40);
            this.txt1.Name = "txt1";
            this.txt1.Size = new System.Drawing.Size(300, 22);
            this.txt1.TabIndex = 2;
            // 
            // txt2
            // 
            this.txt2.Location = new System.Drawing.Point(41, 92);
            this.txt2.Name = "txt2";
            this.txt2.Size = new System.Drawing.Size(300, 22);
            this.txt2.TabIndex = 4;
            // 
            // btn1
            // 
            this.btn1.Location = new System.Drawing.Point(122, 146);
            this.btn1.Name = "btn1";
            this.btn1.Size = new System.Drawing.Size(145, 86);
            this.btn1.TabIndex = 2;
            this.btn1.Text = "Tổng";
            this.btn1.UseVisualStyleBackColor = true;
            this.btn1.Click += new System.EventHandler(this.btn1_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button btn1;
        private System.Windows.Forms.TextBox txt2;
        private System.Windows.Forms.TextBox txt1;
        private System.Windows.Forms.Label Ibl3;
        private System.Windows.Forms.Label Ibl2;
    }
}

