﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Bai_2._10
{
    public partial class Form1 : Form
    {
        private readonly object math;

        public Form1()
        {
            InitializeComponent();
        }

        private void btn4_Click(object sender, EventArgs e)
        {
            Application.Exit();
            
        }

        private void btn1_Click(object sender, EventArgs e)
        {
            double chuvi;
            chuvi = (double.Parse(txt1.Text) + double.Parse(txt2.Text)) * 2;
            txt3.Text = chuvi.ToString();

        }

        private void btn2_Click(object sender, EventArgs e)
        {
            double dt;
            dt = double.Parse(txt1.Text) * double.Parse(txt2.Text);
            txt3.Text = dt.ToString();

        }

        private void btn3_Click(object sender, EventArgs e)
        {
            double duongcheo;
            duongcheo = Math.Sqrt((double.Parse(txt1.Text) + double.Parse(txt2.Text)) * 2);
            txt3.Text = duongcheo.ToString();

        }
    }
}
