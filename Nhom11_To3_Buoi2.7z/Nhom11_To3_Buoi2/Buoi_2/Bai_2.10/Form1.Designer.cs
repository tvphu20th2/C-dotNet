﻿
namespace Bai_2._10
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.txt2 = new System.Windows.Forms.TextBox();
            this.txt1 = new System.Windows.Forms.TextBox();
            this.Ibl3 = new System.Windows.Forms.Label();
            this.Ibl2 = new System.Windows.Forms.Label();
            this.btn4 = new System.Windows.Forms.Button();
            this.btn3 = new System.Windows.Forms.Button();
            this.btn2 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.txt3 = new System.Windows.Forms.TextBox();
            this.IblKetqua = new System.Windows.Forms.Label();
            this.btn1 = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.txt2);
            this.groupBox1.Controls.Add(this.txt1);
            this.groupBox1.Controls.Add(this.Ibl3);
            this.groupBox1.Controls.Add(this.Ibl2);
            this.groupBox1.Location = new System.Drawing.Point(193, 118);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(417, 160);
            this.groupBox1.TabIndex = 16;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Thông tin";
            // 
            // txt2
            // 
            this.txt2.Location = new System.Drawing.Point(41, 92);
            this.txt2.Name = "txt2";
            this.txt2.Size = new System.Drawing.Size(300, 22);
            this.txt2.TabIndex = 4;
            // 
            // txt1
            // 
            this.txt1.Location = new System.Drawing.Point(41, 40);
            this.txt1.Name = "txt1";
            this.txt1.Size = new System.Drawing.Size(300, 22);
            this.txt1.TabIndex = 2;
            // 
            // Ibl3
            // 
            this.Ibl3.AutoSize = true;
            this.Ibl3.Location = new System.Drawing.Point(15, 92);
            this.Ibl3.Name = "Ibl3";
            this.Ibl3.Size = new System.Drawing.Size(20, 17);
            this.Ibl3.TabIndex = 3;
            this.Ibl3.Text = "b:";
            // 
            // Ibl2
            // 
            this.Ibl2.AutoSize = true;
            this.Ibl2.Location = new System.Drawing.Point(15, 43);
            this.Ibl2.Name = "Ibl2";
            this.Ibl2.Size = new System.Drawing.Size(20, 17);
            this.Ibl2.TabIndex = 2;
            this.Ibl2.Text = "a:";
            // 
            // btn4
            // 
            this.btn4.Location = new System.Drawing.Point(494, 341);
            this.btn4.Name = "btn4";
            this.btn4.Size = new System.Drawing.Size(87, 58);
            this.btn4.TabIndex = 21;
            this.btn4.Text = "Thoát";
            this.btn4.UseVisualStyleBackColor = true;
            this.btn4.Click += new System.EventHandler(this.btn4_Click);
            // 
            // btn3
            // 
            this.btn3.Location = new System.Drawing.Point(387, 341);
            this.btn3.Name = "btn3";
            this.btn3.Size = new System.Drawing.Size(87, 58);
            this.btn3.TabIndex = 20;
            this.btn3.Text = "Đường chéo";
            this.btn3.UseVisualStyleBackColor = true;
            this.btn3.Click += new System.EventHandler(this.btn3_Click);
            // 
            // btn2
            // 
            this.btn2.Location = new System.Drawing.Point(294, 341);
            this.btn2.Name = "btn2";
            this.btn2.Size = new System.Drawing.Size(87, 58);
            this.btn2.TabIndex = 19;
            this.btn2.Text = "Diện tích";
            this.btn2.UseVisualStyleBackColor = true;
            this.btn2.Click += new System.EventHandler(this.btn2_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(282, 52);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(178, 34);
            this.label1.TabIndex = 14;
            this.label1.Text = "PHEP TOAN";
            // 
            // txt3
            // 
            this.txt3.Location = new System.Drawing.Point(257, 297);
            this.txt3.Name = "txt3";
            this.txt3.Size = new System.Drawing.Size(324, 22);
            this.txt3.TabIndex = 18;
            // 
            // IblKetqua
            // 
            this.IblKetqua.AutoSize = true;
            this.IblKetqua.Location = new System.Drawing.Point(190, 300);
            this.IblKetqua.Name = "IblKetqua";
            this.IblKetqua.Size = new System.Drawing.Size(61, 17);
            this.IblKetqua.TabIndex = 17;
            this.IblKetqua.Text = "Kết quả:";
            // 
            // btn1
            // 
            this.btn1.Location = new System.Drawing.Point(193, 341);
            this.btn1.Name = "btn1";
            this.btn1.Size = new System.Drawing.Size(87, 58);
            this.btn1.TabIndex = 15;
            this.btn1.Text = "Chu vi";
            this.btn1.UseVisualStyleBackColor = true;
            this.btn1.Click += new System.EventHandler(this.btn1_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.btn4);
            this.Controls.Add(this.btn3);
            this.Controls.Add(this.btn2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txt3);
            this.Controls.Add(this.IblKetqua);
            this.Controls.Add(this.btn1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox txt2;
        private System.Windows.Forms.TextBox txt1;
        private System.Windows.Forms.Label Ibl3;
        private System.Windows.Forms.Label Ibl2;
        private System.Windows.Forms.Button btn4;
        private System.Windows.Forms.Button btn3;
        private System.Windows.Forms.Button btn2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txt3;
        private System.Windows.Forms.Label IblKetqua;
        private System.Windows.Forms.Button btn1;
    }
}

