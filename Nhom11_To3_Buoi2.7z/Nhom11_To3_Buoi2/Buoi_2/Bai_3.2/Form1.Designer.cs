﻿
namespace Bai_3._2
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.Ibl1 = new System.Windows.Forms.Label();
            this.txt1 = new System.Windows.Forms.TextBox();
            this.btn1 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(231, 41);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(127, 17);
            this.label1.TabIndex = 0;
            this.label1.Text = "MUA TRONG NAM";
            // 
            // Ibl1
            // 
            this.Ibl1.AutoSize = true;
            this.Ibl1.Location = new System.Drawing.Point(70, 94);
            this.Ibl1.Name = "Ibl1";
            this.Ibl1.Size = new System.Drawing.Size(53, 17);
            this.Ibl1.TabIndex = 1;
            this.Ibl1.Text = "Thang:";
            // 
            // txt1
            // 
            this.txt1.Location = new System.Drawing.Point(129, 89);
            this.txt1.Name = "txt1";
            this.txt1.Size = new System.Drawing.Size(329, 22);
            this.txt1.TabIndex = 2;
            // 
            // btn1
            // 
            this.btn1.Location = new System.Drawing.Point(208, 152);
            this.btn1.Name = "btn1";
            this.btn1.Size = new System.Drawing.Size(150, 109);
            this.btn1.TabIndex = 3;
            this.btn1.Text = "THONG BAO";
            this.btn1.UseVisualStyleBackColor = true;
            this.btn1.Click += new System.EventHandler(this.btn1_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btn1);
            this.Controls.Add(this.txt1);
            this.Controls.Add(this.Ibl1);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label Ibl1;
        private System.Windows.Forms.TextBox txt1;
        private System.Windows.Forms.Button btn1;
    }
}

