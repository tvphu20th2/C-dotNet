﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Bai_3._7
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btn1_Click(object sender, EventArgs e)
        {
            int a, b, c;
            a = int.Parse(txt1.Text);
            b = int.Parse(txt2.Text);
            c = int.Parse(txt3.Text);

            double denta = (b * b) - (4 * a * c);
            if( denta < 0 )
            {
                txt4.Text = ("Phương trình vô nghiệm");


            }else if(denta == 0){
                txt4.Text = ("Phương trình có nghiệm kép X1 =X2=" + (-b / (2* a)));


            }else
            {
                txt4.Text = ("Phương trình có 2 nghiệm X1=" + ((-b + Math.Sqrt(denta)) / (2 * a))+"X2="+((-b - Math.Sqrt(denta)) / (2 * a)));


            }    
                



        }
    }
}
