﻿
namespace Bai_3._7
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.Ibl1 = new System.Windows.Forms.Label();
            this.Ibl2 = new System.Windows.Forms.Label();
            this.Ibl3 = new System.Windows.Forms.Label();
            this.txt1 = new System.Windows.Forms.TextBox();
            this.txt2 = new System.Windows.Forms.TextBox();
            this.txt3 = new System.Windows.Forms.TextBox();
            this.Ibl4 = new System.Windows.Forms.Label();
            this.txt4 = new System.Windows.Forms.TextBox();
            this.btn1 = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(166, 43);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(464, 39);
            this.label1.TabIndex = 0;
            this.label1.Text = "GIAI PHUONG TRINH BAC 2 ";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.txt3);
            this.groupBox1.Controls.Add(this.txt2);
            this.groupBox1.Controls.Add(this.txt1);
            this.groupBox1.Controls.Add(this.Ibl3);
            this.groupBox1.Controls.Add(this.Ibl2);
            this.groupBox1.Controls.Add(this.Ibl1);
            this.groupBox1.Location = new System.Drawing.Point(173, 118);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(472, 173);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Phương trình";
            // 
            // Ibl1
            // 
            this.Ibl1.AutoSize = true;
            this.Ibl1.Location = new System.Drawing.Point(29, 46);
            this.Ibl1.Name = "Ibl1";
            this.Ibl1.Size = new System.Drawing.Size(20, 17);
            this.Ibl1.TabIndex = 0;
            this.Ibl1.Text = "a:";
            // 
            // Ibl2
            // 
            this.Ibl2.AutoSize = true;
            this.Ibl2.Location = new System.Drawing.Point(29, 85);
            this.Ibl2.Name = "Ibl2";
            this.Ibl2.Size = new System.Drawing.Size(20, 17);
            this.Ibl2.TabIndex = 1;
            this.Ibl2.Text = "b:";
            // 
            // Ibl3
            // 
            this.Ibl3.AutoSize = true;
            this.Ibl3.Location = new System.Drawing.Point(29, 136);
            this.Ibl3.Name = "Ibl3";
            this.Ibl3.Size = new System.Drawing.Size(19, 17);
            this.Ibl3.TabIndex = 2;
            this.Ibl3.Text = "c:";
            // 
            // txt1
            // 
            this.txt1.Location = new System.Drawing.Point(75, 46);
            this.txt1.Name = "txt1";
            this.txt1.Size = new System.Drawing.Size(382, 22);
            this.txt1.TabIndex = 2;
            // 
            // txt2
            // 
            this.txt2.Location = new System.Drawing.Point(75, 85);
            this.txt2.Name = "txt2";
            this.txt2.Size = new System.Drawing.Size(382, 22);
            this.txt2.TabIndex = 3;
            // 
            // txt3
            // 
            this.txt3.Location = new System.Drawing.Point(75, 131);
            this.txt3.Name = "txt3";
            this.txt3.Size = new System.Drawing.Size(382, 22);
            this.txt3.TabIndex = 4;
            // 
            // Ibl4
            // 
            this.Ibl4.AutoSize = true;
            this.Ibl4.Location = new System.Drawing.Point(185, 311);
            this.Ibl4.Name = "Ibl4";
            this.Ibl4.Size = new System.Drawing.Size(57, 17);
            this.Ibl4.TabIndex = 2;
            this.Ibl4.Text = "Kết quả";
            // 
            // txt4
            // 
            this.txt4.Location = new System.Drawing.Point(248, 311);
            this.txt4.Name = "txt4";
            this.txt4.Size = new System.Drawing.Size(382, 22);
            this.txt4.TabIndex = 3;
            // 
            // btn1
            // 
            this.btn1.Location = new System.Drawing.Point(331, 353);
            this.btn1.Name = "btn1";
            this.btn1.Size = new System.Drawing.Size(187, 63);
            this.btn1.TabIndex = 4;
            this.btn1.Text = "Giải";
            this.btn1.UseVisualStyleBackColor = true;
            this.btn1.Click += new System.EventHandler(this.btn1_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btn1);
            this.Controls.Add(this.txt4);
            this.Controls.Add(this.Ibl4);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox txt3;
        private System.Windows.Forms.TextBox txt2;
        private System.Windows.Forms.TextBox txt1;
        private System.Windows.Forms.Label Ibl3;
        private System.Windows.Forms.Label Ibl2;
        private System.Windows.Forms.Label Ibl1;
        private System.Windows.Forms.Label Ibl4;
        private System.Windows.Forms.TextBox txt4;
        private System.Windows.Forms.Button btn1;
    }
}

