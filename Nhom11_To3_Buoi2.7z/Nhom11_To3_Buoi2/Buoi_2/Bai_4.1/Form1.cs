﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Bai_4._1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btn1_Click(object sender, EventArgs e)
        {
           int s=0, n;
            n = int.Parse(txt1.Text);
            //s = double.Parse(txt2.Text);
           for(int i= 0;i<n; i++)
            {
                s = i + i;
            
            }txt2.Text = s.ToString();
            
        }

        private void btn2_Click(object sender, EventArgs e)
        {
            int s = 0, n;
            n = int.Parse(txt1.Text);
            for(int i =0; i<n;i++)
            {
                s = s +( i*i);

            } txt2.Text = s.ToString();
                

        }

        private void btn3_Click(object sender, EventArgs e)
        {
            float s = 0, n;
            n = int.Parse(txt1.Text);
            for (int i = 0; i < n; i++)
            {

                s = s + (float)(1 / (i * 1.0));
            }txt2.Text = s.ToString();  
        }

        private void btn4_Click(object sender, EventArgs e)
        {
           int s = 0, n;
            n = int.Parse(txt1.Text);
            for (int i = 0; i < n; i++)
            {

                s = s + ((2 * i) + 1);
            }
            txt2.Text = s.ToString();

        }

        private void btn5_Click(object sender, EventArgs e)
        {
            int s = 0, n;
            n = int.Parse(txt1.Text);
            for (int i = 0; i < n; i++)
            {

                s = s + (2 * i) + 1;
            }
            txt2.Text = s.ToString();
        }

        private void btn6_Click(object sender, EventArgs e)
        {
            float s = 0; int n;
            n = int.Parse(txt1.Text);
            for (int i = 0; i < n; i++)
            {

                s = s + (float)(1 / (2 * i - 1));
            }
            txt2.Text = s.ToString();
        }

        private void btn7_Click(object sender, EventArgs e)
        {
            int s = 1, n;
            n = int.Parse(txt1.Text);
            for (int i = 0; i < n; i++)
            {

                s = s *i;
            }
            txt2.Text = s.ToString();

        }
    }
}
