﻿
namespace Bai_4._1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Ibl1 = new System.Windows.Forms.Label();
            this.Ibl2 = new System.Windows.Forms.Label();
            this.txt1 = new System.Windows.Forms.TextBox();
            this.txt2 = new System.Windows.Forms.TextBox();
            this.btn1 = new System.Windows.Forms.Button();
            this.btn2 = new System.Windows.Forms.Button();
            this.btn3 = new System.Windows.Forms.Button();
            this.btn4 = new System.Windows.Forms.Button();
            this.btn5 = new System.Windows.Forms.Button();
            this.btn6 = new System.Windows.Forms.Button();
            this.btn7 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // Ibl1
            // 
            this.Ibl1.AutoSize = true;
            this.Ibl1.Location = new System.Drawing.Point(120, 87);
            this.Ibl1.Name = "Ibl1";
            this.Ibl1.Size = new System.Drawing.Size(20, 17);
            this.Ibl1.TabIndex = 0;
            this.Ibl1.Text = "n:";
            // 
            // Ibl2
            // 
            this.Ibl2.AutoSize = true;
            this.Ibl2.Location = new System.Drawing.Point(120, 142);
            this.Ibl2.Name = "Ibl2";
            this.Ibl2.Size = new System.Drawing.Size(21, 17);
            this.Ibl2.TabIndex = 1;
            this.Ibl2.Text = "S:";
            // 
            // txt1
            // 
            this.txt1.Location = new System.Drawing.Point(146, 87);
            this.txt1.Name = "txt1";
            this.txt1.Size = new System.Drawing.Size(229, 22);
            this.txt1.TabIndex = 2;
            // 
            // txt2
            // 
            this.txt2.Location = new System.Drawing.Point(147, 142);
            this.txt2.Name = "txt2";
            this.txt2.Size = new System.Drawing.Size(228, 22);
            this.txt2.TabIndex = 3;
            // 
            // btn1
            // 
            this.btn1.Location = new System.Drawing.Point(84, 209);
            this.btn1.Name = "btn1";
            this.btn1.Size = new System.Drawing.Size(111, 58);
            this.btn1.TabIndex = 4;
            this.btn1.Text = "Tính_4.1";
            this.btn1.UseVisualStyleBackColor = true;
            this.btn1.Click += new System.EventHandler(this.btn1_Click);
            // 
            // btn2
            // 
            this.btn2.Location = new System.Drawing.Point(211, 209);
            this.btn2.Name = "btn2";
            this.btn2.Size = new System.Drawing.Size(111, 58);
            this.btn2.TabIndex = 5;
            this.btn2.Text = "Tính_4.2";
            this.btn2.UseVisualStyleBackColor = true;
            this.btn2.Click += new System.EventHandler(this.btn2_Click);
            // 
            // btn3
            // 
            this.btn3.Location = new System.Drawing.Point(345, 209);
            this.btn3.Name = "btn3";
            this.btn3.Size = new System.Drawing.Size(111, 58);
            this.btn3.TabIndex = 6;
            this.btn3.Text = "Tính_4.3";
            this.btn3.UseVisualStyleBackColor = true;
            this.btn3.Click += new System.EventHandler(this.btn3_Click);
            // 
            // btn4
            // 
            this.btn4.Location = new System.Drawing.Point(84, 310);
            this.btn4.Name = "btn4";
            this.btn4.Size = new System.Drawing.Size(111, 58);
            this.btn4.TabIndex = 7;
            this.btn4.Text = "Tính_4.4";
            this.btn4.UseVisualStyleBackColor = true;
            this.btn4.Click += new System.EventHandler(this.btn4_Click);
            // 
            // btn5
            // 
            this.btn5.Location = new System.Drawing.Point(211, 310);
            this.btn5.Name = "btn5";
            this.btn5.Size = new System.Drawing.Size(111, 58);
            this.btn5.TabIndex = 8;
            this.btn5.Text = "Tính_4.5";
            this.btn5.UseVisualStyleBackColor = true;
            this.btn5.Click += new System.EventHandler(this.btn5_Click);
            // 
            // btn6
            // 
            this.btn6.Location = new System.Drawing.Point(345, 310);
            this.btn6.Name = "btn6";
            this.btn6.Size = new System.Drawing.Size(111, 58);
            this.btn6.TabIndex = 9;
            this.btn6.Text = "Tính_4.6";
            this.btn6.UseVisualStyleBackColor = true;
            this.btn6.Click += new System.EventHandler(this.btn6_Click);
            // 
            // btn7
            // 
            this.btn7.Location = new System.Drawing.Point(483, 265);
            this.btn7.Name = "btn7";
            this.btn7.Size = new System.Drawing.Size(111, 58);
            this.btn7.TabIndex = 10;
            this.btn7.Text = "Tính_4.7";
            this.btn7.UseVisualStyleBackColor = true;
            this.btn7.Click += new System.EventHandler(this.btn7_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btn7);
            this.Controls.Add(this.btn6);
            this.Controls.Add(this.btn5);
            this.Controls.Add(this.btn4);
            this.Controls.Add(this.btn3);
            this.Controls.Add(this.btn2);
            this.Controls.Add(this.btn1);
            this.Controls.Add(this.txt2);
            this.Controls.Add(this.txt1);
            this.Controls.Add(this.Ibl2);
            this.Controls.Add(this.Ibl1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label Ibl1;
        private System.Windows.Forms.Label Ibl2;
        private System.Windows.Forms.TextBox txt1;
        private System.Windows.Forms.TextBox txt2;
        private System.Windows.Forms.Button btn1;
        private System.Windows.Forms.Button btn2;
        private System.Windows.Forms.Button btn3;
        private System.Windows.Forms.Button btn4;
        private System.Windows.Forms.Button btn5;
        private System.Windows.Forms.Button btn6;
        private System.Windows.Forms.Button btn7;
    }
}

