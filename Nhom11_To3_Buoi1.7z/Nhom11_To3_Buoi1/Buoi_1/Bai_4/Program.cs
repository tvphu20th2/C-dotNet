﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bai_4
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.OutputEncoding = Encoding.UTF8;
            MangSoNguyen hn = new MangSoNguyen();
            int n;
            Console.WriteLine("Nhập n = ");
            n = hn.NhapsoDuong();
            int[] a = new int[n];
            Console.WriteLine("Mảng vừa nhập là ");
            hn.NhapMang(a);
            hn.InMang(a);

            Console.WriteLine("\nSố lớn nhất trong mảng là {0}", hn.TimSLN(a,n));
            Console.WriteLine("\nSố lớn nhất trong mảng là {0}", hn.TimSNN(a, n));
            Console.WriteLine("\nTổng các phần tử trong mảng là {0}", hn.TinhTong(a, n));
            Console.WriteLine("\nCác phần tử tăng dần trong mảng là");
           
            hn.SapxepTangdan(a);


         
           
            hn.InMang(a);



            Console.ReadKey();
        }
    }
}
