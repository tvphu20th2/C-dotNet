﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bai_4
{
    class MangSoNguyen
    {
        public int NhapsoDuong()
        {
            int so;
            do
            {
                so = Convert.ToInt32(Console.ReadLine());

            } while (so < 0);
            return so;
        }
        public int NhapSo()
        {
            int so;
            so = Convert.ToInt32(Console.ReadLine());
            return so;
        
        }

        public void NhapMang(int[] a)
        {
            for (int i = 0; i < a.Length; i++)
            {
                Console.WriteLine("Số a[{0}]=", i);
                a[i] = Convert.ToInt32(Console.ReadLine());           
            }    
        
        }

       

        public void InMang(int[] a)
        {
            for (int i = 0; i < a.Length; i++)
            {
                Console.WriteLine("{0}", a[i]);
            
            }    
        
        }
         public int TimSLN (int[] a,int n)
        {
            int max = a[0];
            for (int i = 0; i < n; i++)
            {
                if (max < a[i])
                    max = a[i];

            }
            return max;

        }
        public int TimSNN(int[] a, int n)
        {
            int min = a[0];
            for (int i = 0; i < n; i++)
            {
                if (min > a[i])
                    min = a[i];
               
            }
            return min;

        }
        public int TinhTong(int[] a, int n)
        {
            int tong = 0;
            for (int i = 0; i < n; i++)
            {
                tong += a[i];
            
            
            }
            return tong;
        
        
        }
        public void SapxepTangdan(int[] a)
        {
            int tn;
            for (int i = 0; i < a.Length; i++)
            {
                for (int j = i + 1; j < a.Length; j++)
                {
                    if (a[i] > a[j])
                    {
                        tn = a[i];
                        a[i] = a[j];
                        a[j] = tn;

                    }
                }
            }

        } 

    }
}
