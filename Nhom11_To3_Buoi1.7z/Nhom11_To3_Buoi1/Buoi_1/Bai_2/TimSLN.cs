﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bai_2
{
    class TimSLN
    {
        public int Nhapso()
        {
            int n;
            n = Convert.ToInt32(Console.ReadLine());
            return n;

        }

        public int SLN(int n)
        {
            int max,i,sotam;
            i = 0;
            max = 0;

            do
            {
                Console.WriteLine("Nhập số thứ i={0}", i + 1);
                sotam = Convert.ToInt32(Console.ReadLine());
                if (max < sotam)
                    max = sotam;
                i++;
            } while (i < n);
            return max;
        
        }
    }
}
