﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bai_2
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.OutputEncoding = Encoding.UTF8;
            TimSLN hn = new TimSLN();
            int n;
            Console.WriteLine("Nhập số n=");
            n = hn.Nhapso();
            Console.WriteLine("Số lớn nhất trong số {0} là {1}", n, hn.SLN(n));
            Console.ReadKey();
        }
    }
}
