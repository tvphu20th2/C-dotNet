﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bai_5
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.OutputEncoding = Encoding.UTF8;
            int n;
            Console.WriteLine("Nhập số lượng học sinh:");
            n = int.Parse(Console.ReadLine());
            Sinhvien[] tn = new Sinhvien[n]; 
            for(int i=0;i<n;i++)
            {
                Console.WriteLine("Nhập thành viên thứ:", (i + 1).ToString());

                tn[i] = new Sinhvien();
                tn[i].Nhap();


            }
            Console.WriteLine(" Danh sach hoc sinh: ");
            Console.WriteLine("{0,-15}{1,-15}{2,-15}{3,-15}", "Ho Ten", "Diem Toan", "Diem Van", "DTB");
            for(int i=0;i<n;i++)
            {
                tn[i].Xuat();
            }    



            Console.ReadKey();
        }
    }
}
