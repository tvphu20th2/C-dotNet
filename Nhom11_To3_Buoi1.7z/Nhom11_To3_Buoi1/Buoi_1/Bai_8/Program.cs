﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bai_8
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.OutputEncoding = Encoding.UTF8;
            TamGiac tn = new TamGiac();
            tn._Tinhcv();
            tn._Dientich();
            tn.hienthi();

            
            Console.ReadLine();
        }
    }
}
