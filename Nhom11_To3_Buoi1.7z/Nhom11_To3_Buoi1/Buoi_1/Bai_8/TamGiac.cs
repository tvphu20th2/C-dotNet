﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bai_8
{
    class TamGiac
    {
        private int canh1;
        private int canh2;
        private int canh3;
        private int chuvi;
        private int Loai;
        private float dientich;


        public int Canha
        {
            get { return canh1; }
            set { canh1 = value; }

        }
        public int Canhb
        {
            get { return canh2; }
            set { canh2 = value; }

        }
        public int Canhc
        {
            get { return canh3; }
            set { canh3 = value; }

        }
        public int Chuvi
        {
            get { return chuvi; }
            set { chuvi = value; }

        }
        public int loai
        {
            get { return Loai; }
            set { Loai = value; }

        }
        public float Dientich
        {
            get { return dientich; }
            set { dientich = value; }
        }
        // phương thức khởi tạo không tham số vs giá trị cho sẳn
        public TamGiac()
        {
            this.Canha = 2;
            this.Canhb = 3;
            this.Canhc = -5;

        }
        //phương thức khởi tạo có tham số
        public TamGiac(int a, int b, int c)
        {
            this.Canha = a;
            this.Canhb = b;
            this.Canhc = c;

        }

        public void hienthi()
        {
            Console.WriteLine("3 cạnh của tam giác {0},{1},{2}", canh1, canh2, canh3);
        }
        public float _Tinhcv()
        {
            float chuvi;
            chuvi = Canha + Canhb + Canhc;

            Console.WriteLine("Chu vi là {0}:", chuvi);
            return chuvi;


        }
        public float _Dientich()
        {
            float dt;
            float p = chuvi / 2;
            dt= (float) Math.Sqrt(p * (p - Canha) * (p - Canhb) * (p - Canhc));
            Console.WriteLine("Diện tích là:{0}", dt);

            return dt;

        }





    }

}
