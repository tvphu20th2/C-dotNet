﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bai_9
{
    class Phuongtrinhbac2
    {
        private int Soa;
        private int Sob;
        private int Soc;
        


        public Phuongtrinhbac2()
        {
            Soa = 0;
            Sob = 0;
            Soc = 0;


        }
        public Phuongtrinhbac2(int a,int b,int c)
        {
            this.Soa = a;
            this.Sob=b;
            this.Soc = c;

        }

        public void Nhap()
        {
            Console.WriteLine("Nhập canh a =");
            Soa = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Nhập canh b =");
            Sob = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Nhập canh c =");
            Soc = Convert.ToInt32(Console.ReadLine());

        }

    }
    
    
    
    



}
