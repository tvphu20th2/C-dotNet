﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bai_3
{
    class GiaiThuaN
    {
        public int Nhapso()
        {
            int so;
            do
            {
                so = Convert.ToInt32(Console.ReadLine());

            } while (so < 0);
            return so;
        }
        public long GiaiThua(int n)
        {
            long gt = 1;
            for (int i = 1; i <= n; i++)
            {
                gt = gt * i;
            }
            return gt;
        }
        
    }
}
