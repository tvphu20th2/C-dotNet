﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bai_3
{
    class Program
    {
        static void Main(string[] args)
        {
            
            Console.OutputEncoding = Encoding.UTF8;
            GiaiThuaN hn = new GiaiThuaN();
            int n;
            Console.WriteLine("Nhập n =");
            n = hn.Nhapso();
            Console.WriteLine("Giai thừa của {0} là {1}", n, hn.GiaiThua(n));
            Console.ReadKey();
        }
    }
}
