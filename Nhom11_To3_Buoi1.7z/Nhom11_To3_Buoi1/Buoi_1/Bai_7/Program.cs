﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bai_7
{
    class Program
    {
        static void Main(string[] args)
        {
            NhanVien hn = new NhanVien();
            Console.OutputEncoding = Encoding.UTF8;
            int n;
            Console.WriteLine("Nhập số lượng nhân viên :");
            n = int.Parse(Console.ReadLine());
            NhanVien[] o = new NhanVien[n];
            for(int i =0;i<n;i++)
            {
                Console.WriteLine("Nhập thành viên thứ "+( i + 1).ToString());
                o[i] = new NhanVien();



                o[i].Input();

            }
            Console.WriteLine("Danh sách nhân viên :");
             Console.WriteLine("{0,-15}{1,-15}{2,-15}{3,-15}{4,-15}", "So", "Ho ten", "Namsinh", "luong co ban", "bậc lương");
            for(int i =0;i<n;i++)
            {
                o[i].OutPut();
            }    



            Console.ReadKey();


        }
    }
}
