﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bai_7
{
    class NhanVien
    {
        private int id;
        private String name;
        private int yearOfBrith;
        private double salaryLevel;
        public double basicSalary;

        //phương thức khởi tạo 
        public NhanVien()
        {
            id = 0; ;
            basicSalary = 0;
            name = "";
            yearOfBrith = 0;
            salaryLevel = 0;
        }
        //Các phương thức Properties để get/set giá trị cho các thuộc tính
        public int So
        {
            get { return id; }
            set { id = value; }

        }
        public String Hoten
        {
            get { return name; }
            set { name = value; }
        }
        public int Namsinh
        {
            get { return yearOfBrith; }
            set { yearOfBrith = value; }
            
        }
        public double Bacluong
        {
            get { return salaryLevel; }
            set { salaryLevel = value; }

        }
        public double luongcoban
        {
            get { return basicSalary; }
            set { basicSalary = value; }
        }

        public void Input() 
        {
            Console.WriteLine("Nhập id :");
            int tn = int.Parse(Console.ReadLine());  
            So = tn;
            

            Console.WriteLine("Nhập họ tên:");
            Hoten = Console.ReadLine();
            Console.WriteLine("Nhập năm sinh:");
            tn = int.Parse(Console.ReadLine());
            Namsinh = tn;
            Console.WriteLine("Nhập lương cơ bản:");
            tn = int.Parse(Console.ReadLine());
            luongcoban = tn;
            Console.WriteLine("Nhập bậc lương:");
            tn = int.Parse(Console.ReadLine());
            Bacluong = tn;

        }
        public void OutPut()
        {

            Console.WriteLine("{0,-15}{1,-15}{2,-15}{3,-15}{4,-15}", So, Hoten, Namsinh, luongcoban, Bacluong);

        }

        







    }
}