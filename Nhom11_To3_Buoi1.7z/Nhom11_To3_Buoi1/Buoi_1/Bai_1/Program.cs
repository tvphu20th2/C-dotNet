﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bai_1
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.OutputEncoding = Encoding.UTF8;
            TimMax hn = new TimMax();
            int a, b, c, max;
            Console.WriteLine("Nhập a: ");
            a = hn.NhapSo();
            Console.WriteLine("Nhập b: ");
            b = hn.NhapSo();
            Console.WriteLine("Nhập c: ");
            c = hn.NhapSo();
            max = hn.Timmax(a,b,c);
            Console.WriteLine("số lớn nhất trong ba số {0} , {1},{2} là {3}", a, b, c,max);
            Console.ReadKey();

        }
    }
}
